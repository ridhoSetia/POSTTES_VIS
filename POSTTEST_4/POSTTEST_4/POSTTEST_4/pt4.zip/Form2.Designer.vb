﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        pbFotoKartu = New PictureBox()
        lblNamaKartu = New Label()
        lblIDKartu = New Label()
        lblDivisiKartu = New Label()
        lblKontakKartu = New Label()
        lblHobiKartu = New Label()
        PanelKartu = New Panel()
        LabelJudul = New Label()
        Panel1 = New Panel()
        CType(pbFotoKartu, ComponentModel.ISupportInitialize).BeginInit()
        PanelKartu.SuspendLayout()
        SuspendLayout()
        ' 
        ' pbFotoKartu
        ' 
        pbFotoKartu.BorderStyle = BorderStyle.Fixed3D
        pbFotoKartu.Location = New Point(486, 56)
        pbFotoKartu.Name = "pbFotoKartu"
        pbFotoKartu.Size = New Size(163, 233)
        pbFotoKartu.SizeMode = PictureBoxSizeMode.StretchImage
        pbFotoKartu.TabIndex = 0
        pbFotoKartu.TabStop = False
        ' 
        ' lblNamaKartu
        ' 
        lblNamaKartu.Font = New Font("Segoe UI", 11.0F, FontStyle.Bold)
        lblNamaKartu.Location = New Point(114, 77)
        lblNamaKartu.Name = "lblNamaKartu"
        lblNamaKartu.Size = New Size(327, 25)
        lblNamaKartu.TabIndex = 1
        ' 
        ' lblIDKartu
        ' 
        lblIDKartu.Location = New Point(114, 107)
        lblIDKartu.Name = "lblIDKartu"
        lblIDKartu.Size = New Size(327, 20)
        lblIDKartu.TabIndex = 2
        ' 
        ' lblDivisiKartu
        ' 
        lblDivisiKartu.Location = New Point(114, 132)
        lblDivisiKartu.Name = "lblDivisiKartu"
        lblDivisiKartu.Size = New Size(327, 20)
        lblDivisiKartu.TabIndex = 3
        ' 
        ' lblKontakKartu
        ' 
        lblKontakKartu.Location = New Point(114, 157)
        lblKontakKartu.Name = "lblKontakKartu"
        lblKontakKartu.Size = New Size(327, 20)
        lblKontakKartu.TabIndex = 4
        ' 
        ' lblHobiKartu
        ' 
        lblHobiKartu.Font = New Font("Segoe UI", 8.0F, FontStyle.Italic)
        lblHobiKartu.Location = New Point(114, 207)
        lblHobiKartu.Name = "lblHobiKartu"
        lblHobiKartu.Size = New Size(327, 45)
        lblHobiKartu.TabIndex = 5
        ' 
        ' PanelKartu
        ' 
        PanelKartu.BackColor = Color.White
        PanelKartu.BackgroundImage = CType(resources.GetObject("PanelKartu.BackgroundImage"), Image)
        PanelKartu.BackgroundImageLayout = ImageLayout.Center
        PanelKartu.BorderStyle = BorderStyle.FixedSingle
        PanelKartu.Controls.Add(pbFotoKartu)
        PanelKartu.Controls.Add(lblNamaKartu)
        PanelKartu.Controls.Add(lblIDKartu)
        PanelKartu.Controls.Add(lblDivisiKartu)
        PanelKartu.Controls.Add(lblKontakKartu)
        PanelKartu.Controls.Add(LabelJudul)
        PanelKartu.Controls.Add(lblHobiKartu)
        PanelKartu.Controls.Add(Panel1)
        PanelKartu.Location = New Point(12, 12)
        PanelKartu.Name = "PanelKartu"
        PanelKartu.Size = New Size(741, 331)
        PanelKartu.TabIndex = 0
        ' 
        ' LabelJudul
        ' 
        LabelJudul.BackColor = Color.Transparent
        LabelJudul.Dock = DockStyle.Top
        LabelJudul.Font = New Font("Arial", 12.0F, FontStyle.Bold)
        LabelJudul.ForeColor = Color.Black
        LabelJudul.Location = New Point(0, 0)
        LabelJudul.Name = "LabelJudul"
        LabelJudul.Size = New Size(739, 40)
        LabelJudul.TabIndex = 6
        LabelJudul.Text = "KARTU ANGGOTA IMPHNEN"
        LabelJudul.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.BackgroundImageLayout = ImageLayout.Center
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Location = New Point(54, 56)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(409, 233)
        Panel1.TabIndex = 7
        ' 
        ' Form2
        ' 
        ClientSize = New Size(765, 355)
        Controls.Add(PanelKartu)
        Name = "Form2"
        Text = "Digital ID Card"
        CType(pbFotoKartu, ComponentModel.ISupportInitialize).EndInit()
        PanelKartu.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents pbFotoKartu As PictureBox
    Friend WithEvents lblNamaKartu As Label
    Friend WithEvents lblIDKartu As Label
    Friend WithEvents lblDivisiKartu As Label
    Friend WithEvents lblKontakKartu As Label
    Friend WithEvents lblHobiKartu As Label
    Friend WithEvents PanelKartu As Panel
    Friend WithEvents LabelJudul As Label
    Friend WithEvents Panel1 As Panel
End Class