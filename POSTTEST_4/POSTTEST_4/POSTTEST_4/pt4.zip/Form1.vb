﻿Public Class Form1

    ' 1. VALIDASI: NAMA HANYA HURUF
    Private Sub txtNama_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNama.KeyPress
        ' Membolehkan huruf, tombol hapus (backspace), dan spasi
        If Not Char.IsLetter(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsWhiteSpace(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    ' 2. VALIDASI: ID HANYA ANGKA
    Private Sub txtID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtID.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    ' 3. FUNGSI BROWSE FOTO
    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        OpenFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp"
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            pbProfil.Image = Image.FromFile(OpenFileDialog1.FileName)
        End If
    End Sub

    ' 4. FUNGSI SIMPAN & CETAK (KE FORM 2)
    Private Sub btnSimpanCetak_Click(sender As Object, e As EventArgs) Handles btnSimpanCetak.Click
        ' Cek Inputan Kosong
        If txtNama.Text = "" Or txtID.Text = "" Or txtEmail.Text = "" Or txtAlamat.Text = "" Or cmbDivisi.Text = "" Then
            MessageBox.Show("Inputan tidak boleh kosong!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Cek MaskedTextBox
        If Not mtxtTelepon.MaskCompleted Then
            MessageBox.Show("Inputan tidak boleh kosong (Nomor Telepon belum lengkap)!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Cek Checkbox (Hobby)
        Dim hobbyTerpilih As String = ""
        For Each ctrl In GroupBox2.Controls
            If TypeOf ctrl Is CheckBox AndAlso DirectCast(ctrl, CheckBox).Checked Then
                hobbyTerpilih &= DirectCast(ctrl, CheckBox).Text & ", "
            End If
        Next

        If hobbyTerpilih = "" Then
            MessageBox.Show("Inputan tidak boleh kosong (Pilih minimal 1 hobby)!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Konfirmasi Simpan & Pindah Form
        Dim tanya = MessageBox.Show("Apakah Anda yakin ingin simpan dan cetak?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If tanya = DialogResult.Yes Then
            ' Membuka FormHasil (Form2)
            Dim f2 As New Form2()
            f2.TampilkanData(txtNama.Text, txtID.Text, cmbDivisi.Text, mtxtTelepon.Text, hobbyTerpilih, pbProfil.Image)
            f2.Show()
        End If
    End Sub

    ' 5. NAVIGASI MENU (DENGAN PENGECEKAN OBJEK AGAR TIDAK ERROR)
    Private Sub InputDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InputDataToolStripMenuItem.Click
        Try
            TabControl1.SelectedTab = TabPage1
        Catch ex As Exception
            ' Jika gagal memanggil TabPage1, gunakan index
            TabControl1.SelectedIndex = 0
        End Try
    End Sub

    Private Sub LihatKartuToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LihatKartuToolStripMenuItem.Click
        Try
            ' Tab 3 biasanya index ke-2
            TabControl1.SelectedIndex = 2
        Catch ex As Exception
            MessageBox.Show("Tab Profil & Aktivitas tidak ditemukan!")
        End Try
    End Sub

    ' 6. MENU KELUAR
    Private Sub KeluarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles KeluarToolStripMenuItem.Click
        Dim konfirmasi = MessageBox.Show("Apakah anda yakin ingin keluar?", "Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        If konfirmasi = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    ' 7. SIMPAN DATA KE FILE
    Private Sub SimpanDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SimpanDataToolStripMenuItem.Click
        SaveFileDialog1.Filter = "Text Files (*.txt)|*.txt"
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            IO.File.WriteAllText(SaveFileDialog1.FileName, "Nama: " & txtNama.Text & vbCrLf & "ID: " & txtID.Text)
            MessageBox.Show("Data berhasil disimpan!", "Informasi")
        End If
    End Sub

End Class
