﻿Public Class Form2
    ' Sub rutin untuk mengisi data kartu dari Form1
    Public Sub TampilkanData(nama As String, id As String, divisi As String, kontak As String, hobi As String, foto As Image)
        lblNamaKartu.Text = "Nama: " & nama
        lblIDKartu.Text = "ID: " & id
        lblDivisiKartu.Text = "Divisi: " & divisi
        lblKontakKartu.Text = "Telp: " & kontak
        lblHobiKartu.Text = "Hobi/Aktivitas: " & hobi
        If foto IsNot Nothing Then
            pbFotoKartu.Image = foto
        End If
    End Sub
End Class